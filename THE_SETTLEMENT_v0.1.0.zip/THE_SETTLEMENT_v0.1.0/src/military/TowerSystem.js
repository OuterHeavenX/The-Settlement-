Settlement.TowerSystem=class{
 constructor(game){this.game=game;this.cool=new Map}
 update(dt){
  for(const b of this.game.buildings.list){
   if(!b.complete||b.type!=="archery")continue;
   let d=Settlement.BuildingDefs.archery,c=(this.cool.get(b.id)||0)-dt;
   if(c>0){this.cool.set(b.id,c);continue}
   let bx=(b.x+.5)*64,by=(b.y+.5)*64,range=d.range*64;
   let target=this.game.enemies.list.filter(e=>e.hp>0).sort((a,z)=>Math.hypot(a.x-bx,a.y-by)-Math.hypot(z.x-bx,z.y-by))[0];
   if(target&&Math.hypot(target.x-bx,target.y-by)<=range){
    let eff=b.workers?1:.25;
    target.hp-=d.damage*eff;
    this.game.effects.shot(bx,by,target.x,target.y);
    this.cool.set(b.id,1/d.fireRate);
    if(target.hp<=0)this.game.enemies.kill(target);
   }
  }
 }
};
