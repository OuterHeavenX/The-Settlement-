Settlement.Renderer=class{
 constructor(game,canvas){this.game=game;this.c=canvas;this.ctx=canvas.getContext("2d",{alpha:false});this.dpr=1;this.resize()}
 resize(){this.dpr=Math.min(2,devicePixelRatio||1);this.c.width=Math.floor(innerWidth*this.dpr);this.c.height=Math.floor(innerHeight*this.dpr);this.c.style.width=innerWidth+"px";this.c.style.height=innerHeight+"px"}
 isoRect(ctx,x,y,w,h,fill,stroke){ctx.fillStyle=fill;ctx.fillRect(x,y,w,h);ctx.strokeStyle=stroke||"#0003";ctx.strokeRect(x+.5,y+.5,w-1,h-1)}
 draw(){
  let g=this.game,ctx=this.ctx,C=Settlement.Config,cam=g.camera,W=this.c.width,H=this.c.height;ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle="#657d45";ctx.fillRect(0,0,W,H);
  ctx.save();ctx.translate(W/2,H/2);ctx.scale(cam.zoom*this.dpr,cam.zoom*this.dpr);ctx.translate(-cam.x,-cam.y);
  let halfW=W/(2*cam.zoom*this.dpr)+128,halfH=H/(2*cam.zoom*this.dpr)+128,minx=Math.max(0,Math.floor((cam.x-halfW)/64)),maxx=Math.min(C.WORLD_W,Math.ceil((cam.x+halfW)/64)),miny=Math.max(0,Math.floor((cam.y-halfH)/64)),maxy=Math.min(C.WORLD_H,Math.ceil((cam.y+halfH)/64));
  for(let y=miny;y<maxy;y++)for(let x=minx;x<maxx;x++){let claimed=g.expansion.isClaimed(x,y),n=((x*73856093)^(y*19349663))&7;ctx.fillStyle=claimed?(n<2?"#8eaa63":"#91ad68"):(n<2?"#607846":"#657d49");ctx.fillRect(x*64,y*64,64,64);if(claimed){ctx.strokeStyle="#ffffff0d";ctx.strokeRect(x*64,y*64,64,64)}else if(n===0){ctx.fillStyle="#415d34";ctx.beginPath();ctx.arc(x*64+18,y*64+23,7,0,7);ctx.fill()}}
  let p=g.expansion.preview;if(!g.expansion.claimed){ctx.fillStyle="#cfc47718";ctx.fillRect(p.x*64,p.y*64,p.w*64,p.h*64);ctx.strokeStyle="#e9d98999";ctx.setLineDash([10,8]);ctx.lineWidth=3;ctx.strokeRect(p.x*64,p.y*64,p.w*64,p.h*64);ctx.setLineDash([])}
  for(let b of [...g.buildings.list].sort((a,b)=>(a.y+a.h)-(b.y+b.h)))this.building(b);
  for(let c of g.citizens.list)this.citizen(c);
  for(let e of g.enemies.list)this.enemy(e);
  if(g.placement.type&&g.placement.hover){let {x,y}=g.placement.hover,d=Settlement.BuildingDefs[g.placement.type],v=g.placement.validate(g.placement.type,x,y);ctx.fillStyle=v.ok?"#aef78566":"#ff6b5a66";ctx.fillRect(x*64,y*64,d.footprint[0]*64,d.footprint[1]*64);ctx.strokeStyle=v.ok?"#d9ffb7":"#ffb2a8";ctx.lineWidth=3;ctx.strokeRect(x*64,y*64,d.footprint[0]*64,d.footprint[1]*64)}
  for(let s of g.effects.shots){ctx.strokeStyle="#f4df8c";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(s.x1,s.y1);ctx.lineTo(s.x2,s.y2);ctx.stroke()}
  for(let f of g.effects.floaters){ctx.globalAlpha=Math.min(1,f.t);ctx.font="bold 20px Georgia";ctx.textAlign="center";ctx.fillStyle="#fff2bd";ctx.strokeStyle="#2c1b10";ctx.lineWidth=4;ctx.strokeText(f.text,f.x,f.y-(1.4-f.t)*22);ctx.fillText(f.text,f.x,f.y-(1.4-f.t)*22);ctx.globalAlpha=1}
  ctx.restore();
 }
 building(b){let ctx=this.ctx,d=Settlement.BuildingDefs[b.type],x=b.x*64,y=b.y*64,w=b.w*64,h=b.h*64;if(!b.complete){ctx.fillStyle="#896944";ctx.fillRect(x+5,y+5,w-10,h-10);ctx.strokeStyle="#e5d2a0";ctx.strokeRect(x+8,y+8,w-16,h-16);ctx.fillStyle="#402c1d";ctx.fillRect(x+8,y+h-13,(w-16)*b.progress,6);ctx.fillStyle="#fff";ctx.font="16px serif";ctx.fillText("🔨",x+w/2-8,y+h/2);return}
  if(b.type==="farm"){let p=this.game.farms.plots.get(b.id);ctx.fillStyle="#6d4d2b";ctx.fillRect(x+4,y+4,w-8,h-8);for(let yy=0;yy<4;yy++)for(let xx=0;xx<4;xx++){ctx.strokeStyle="#4b331e";ctx.beginPath();ctx.moveTo(x+10+xx*28,y+8);ctx.lineTo(x+10+xx*28,y+h-8);ctx.stroke();if(p&&p.state!=="empty"){ctx.fillStyle=p.state==="ready"?"#e0c555":"#7ca34f";ctx.beginPath();ctx.arc(x+16+xx*28,y+18+yy*25,4+3*p.progress,0,7);ctx.fill()}}return}
  if(b.type==="wall"||b.type==="gate"){ctx.fillStyle=b.type==="gate"?"#5e3b21":"#74502c";ctx.fillRect(x+6,y+16,52,32);ctx.strokeStyle="#3b2819";ctx.lineWidth=4;ctx.strokeRect(x+8,y+18,48,28);if(b.type==="gate"){ctx.strokeStyle="#d0ad66";ctx.beginPath();ctx.moveTo(x+32,y+18);ctx.lineTo(x+32,y+46);ctx.stroke()}return}
  if(b.type==="road"){ctx.fillStyle="#9a825f";ctx.fillRect(x+8,y+20,48,24);return}
  ctx.fillStyle="#5c3b22";ctx.fillRect(x+8,y+h*.45,w-16,h*.45);ctx.fillStyle=b.type==="archery"?"#73614d":"#c9b27e";ctx.fillRect(x+14,y+h*.28,w-28,h*.45);ctx.fillStyle="#5a3420";ctx.beginPath();ctx.moveTo(x+5,y+h*.34);ctx.lineTo(x+w/2,y+5);ctx.lineTo(x+w-5,y+h*.34);ctx.closePath();ctx.fill();ctx.font=Math.min(34,w*.32)+"px serif";ctx.textAlign="center";ctx.fillText(d.icon,x+w/2,y+h*.63);if(d.workers){ctx.font="13px Georgia";ctx.fillStyle="#fff2cf";ctx.strokeStyle="#29180f";ctx.lineWidth=3;let t=(b.workers||0)+"/"+d.workers;ctx.strokeText(t,x+w-18,y+18);ctx.fillText(t,x+w-18,y+18)}
 }
 citizen(c){let ctx=this.ctx;ctx.fillStyle="#d8b17b";ctx.beginPath();ctx.arc(c.x,c.y-7,5,0,7);ctx.fill();ctx.fillStyle=c.job==="Archer"?"#48613d":c.job==="Lumberjack"?"#6c4b2c":"#7a4750";ctx.fillRect(c.x-5,c.y-2,10,13);ctx.fillStyle="#2b241c";ctx.fillRect(c.x-5,c.y+11,4,6);ctx.fillRect(c.x+1,c.y+11,4,6)}
 enemy(e){let ctx=this.ctx;ctx.fillStyle="#5e2925";ctx.beginPath();ctx.arc(e.x,e.y,10,0,7);ctx.fill();ctx.fillStyle="#241516";ctx.fillRect(e.x-8,e.y-3,16,16);ctx.fillStyle="#321717";ctx.fillRect(e.x-15,e.y-20,30,4);ctx.fillStyle="#c25243";ctx.fillRect(e.x-15,e.y-20,30*(e.hp/e.maxHp),4)}
};
